<html>
  <head>
    <title>Voting Poll</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
  </head>
  <body>
    <div id="container">
      <div id="header">
        <h1><img src="cybercat2.jpg" title=" " alt=" " /></h1>
      </div>
      <div id="content">
        <div id="nav">
          <h3>Navigation </h3>
          <ul>
            <li><a href="index.php">Main</a></li>
          </ul>
        </div>
        
        <div id="main">
          <h2>Create Poll</h2>
  <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST')
        {
	      	
          validate();
        }
        
        function validate()
        {
	      	    $db = new PDO("mysql:host=localhost;dbname=gillilandr",'gillilandr','12345');
	            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	      	
	      	    // varibles from the user input
	      	 		$question = $_POST['question'];
	      		  $choice1 = $_POST['choice1'];
	      			$choice2 = $_POST['choice2'];
	      			$choice3 = $_POST['choice3'];
							$choice4 = $_POST['choice4'];
	      			$questionId = $_POST['id'];
	      	    
	      			
             		
	      			/*Gets the databases questions and compares with the one inputed
	      			   by the user if the same tells the user to input another question*/
	      			$same = 0;
	      			$db_question = array();
	      			$result = $db->query("SELECT question from polls");
	      			foreach($result as $row)
	      			{
	      				$db_question[] = $row['question'];
	      			}
	      			for($x=0; $x < sizeof($db_question); $x++)
	      			{
	      				$compare_question = $db_question[$x];
	      				if($question == $compare_question)
	      					$same = 1;
	      			}
	      	
	      			//checks to see if something is blank or duplicated and sends message
	      			if($same == 1)
	      			{
	      				$question = NULL;
	      				print "<p>Poll question is already created Try Again.</p>";
	      			}
	      			
	      	    if(empty($question))
	      			{
	      	    	$question = NULL;
	      	    	print "<p>Please enter a Poll question.</p>";
	      	    }
	      			 
	      	
	      			/* Takes the question and enters it into the database.
	      			*/
	      	   
	      				
	      		              $stmt = $db->prepare("INSERT INTO polls(question) VALUES(:uquestion)");
                          $stmt->bindparam(":uquestion",$question);

	      		              
	      		              //execute the prepared statement		
	      		              $stmt->execute();
					     //Takes the question id and enters in the choices
												 $stmt = $db->prepare("INSERT INTO polls_choices(poll, name) VALUES(:upoll, :uname)");
													$stmt->bindparam(":upoll",$questionId);
                          $stmt->bindparam(":uname",$choice1);
	      		              //execute the prepared statement		
	      		              $stmt->execute();
							 $stmt = $db->prepare("INSERT INTO polls_choices(poll, name) VALUES(:upoll, :uname)");
													$stmt->bindparam(":upoll",$questionId);
                          $stmt->bindparam(":uname",$choice2);
	      		              //execute the prepared statement		
	      		              $stmt->execute();
							 $stmt = $db->prepare("INSERT INTO polls_choices(poll, name) VALUES(:upoll, :uname)");
													$stmt->bindparam(":upoll",$questionId);
                          $stmt->bindparam(":uname",$choice3);
	      		              //execute the prepared statement		
	      		              $stmt->execute();
							 $stmt = $db->prepare("INSERT INTO polls_choices(poll, name) VALUES(:upoll, :uname)");
													$stmt->bindparam(":upoll",$questionId);
                          $stmt->bindparam(":uname",$choice4);
	      		              //execute the prepared statement		
	      		              $stmt->execute();
	 				
	      	    
        }//end of validate
	?>
          
        <div id="form">
         <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
   
    
    <input name="question" type="text" id="question" placeholder="Poll Question" value='<?php
        if((isset($_POST['question'])) && (strlen($_POST['question']) > 0))
          echo $_POST['question'];?>' ><br>
	  <input name="choice1" type="text" id="choice1" placeholder="First Choice for Poll" value='<?php
        if((isset($_POST['choice1'])) && (strlen($_POST['choice1']) > 0))
          echo $_POST['choice1'];?>' ><br>
	  <input name="choice2" type="text" id="choice2" placeholder="Second Choice for Poll" value='<?php
        if((isset($_POST['choice2'])) && (strlen($_POST['choice2']) > 0))
          echo $_POST['choice2'];?>' ><br>
	  <input name="choice3" type="text" id="choice3" placeholder="Third Choice for Poll" value='<?php
        if((isset($_POST['choice3'])) && (strlen($_POST['choice3']) > 0))
          echo $_POST['choice3'];?>' ><br>
	  <input name="choice4" type="text" id="choice4" placeholder="Fourth Choice for Poll" value='<?php
        if((isset($_POST['choice4'])) && (strlen($_POST['choice4']) > 0))
          echo $_POST['choice4'];?>' ><br>
		

	
	  <input type="submit" value="Enter Poll" name="submit" />
	 
</form>
        </div>
       </div>
      </div>
      <div id="footer">
        Copyright &copy; 2017 Purrfect Software
      </div>
    </div>
  </body>
</html>